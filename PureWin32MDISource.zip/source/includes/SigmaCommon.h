#if !defined(_SIGMA_SIGMACOMMOM_H_INCLUDED_)
#define _SIGMA_SIGMACOMMOM_H_INCLUDED_

#define MAILSLOTNAME "\\\\.\\mailslot\\sigmamain"

#endif