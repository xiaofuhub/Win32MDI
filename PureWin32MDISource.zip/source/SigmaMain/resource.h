//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SigmaMain.rc
//
#define IDR_MAINFRAME_MENU              101
#define IDI_SIGMA_MAIN_ICON             104
#define IDI_SYSTEM_INFO                 106
#define IDR_SYSINFO_MENU                108
#define ID_INFORMATION_SYSTEMINFORMATION 40001
#define ID_HELP_ABOUT                   40002
#define ID_WINDOWS_CASCADE              40003
#define ID_FILE_EXIT                    40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
